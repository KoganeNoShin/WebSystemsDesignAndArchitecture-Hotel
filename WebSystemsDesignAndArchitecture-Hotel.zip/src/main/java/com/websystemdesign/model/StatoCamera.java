package com.websystemdesign.model;

public enum StatoCamera {
    LIBERA,
    OCCUPATA,
    DA_PULIRE
}
