package com.websystemdesign.model;

public enum Ruolo {
    CLIENTE,
    STAFF,
    AMMINISTRATORE
}
