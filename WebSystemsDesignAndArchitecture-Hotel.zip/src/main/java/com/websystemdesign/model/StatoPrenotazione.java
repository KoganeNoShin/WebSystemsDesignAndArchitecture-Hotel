package com.websystemdesign.model;

public enum StatoPrenotazione {
    CONFERMATA,
    CHECKED_IN,
    CHECKED_OUT,
    CANCELLATA
}
